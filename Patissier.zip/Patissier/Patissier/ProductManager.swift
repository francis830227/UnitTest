//
//  ProductManager.swift
//  Patissier
//
//  Created by Francis Tseng on 2017/6/29.
//  Copyright © 2017年 Francis Tseng. All rights reserved.
//

import Foundation
import Alamofire
import UIKit

struct Product {
    var name: String
    var price: Double
    var id: String
}

var products = [Product]()

var urlPage = ""

var nextPage = ""

protocol ProductManagerDelegate {

    func manager(_ manager: ProductManager, didGet products: [Product])

    func manager(_ manager: ProductManager, didFailWith error: Error)
}

class ProductManager {

    static let shared = ProductManager()

    var delegate: ProductManagerDelegate?

    func requestProducts() {
        print("--------request")

        let url = URL(string: "http://52.198.40.72/patissier/api/v1/products\(urlPage)")!
        let token = UserDefaults.standard.string(forKey: "jwt")!
        Alamofire.request(url, method: .get, headers: ["Authorization": "Bearer \(token)"]).responseJSON { response in

            if let responseJSON = response.result.value {
                if let downloadJSON = responseJSON as? [String: Any] {
                    if let productData = downloadJSON["data"] as? [[String: Any]] {
                        for product in productData {
                            if let price = product["price"] as? Double, let name = product["name"] as? String, let id = product["id"] as? String {
                                products.append(Product(name: name, price: price, id: id))
                        }
                    }
                    self.delegate?.manager(self, didGet: products)
                }
                if let downloadPaging = downloadJSON["paging"] as? [String: String] {
                    if let secondPaging = downloadPaging["next"] {
                        nextPage = secondPaging
                        urlPage = "?paging=\(nextPage)"
                    }
                }
            }
        }
        }.resume()
    }
}
