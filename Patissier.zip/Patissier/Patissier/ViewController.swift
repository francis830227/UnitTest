//
//  ViewController.swift
//  Patissier
//
//  Created by Francis Tseng on 2017/6/21.
//  Copyright © 2017年 Francis Tseng. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import UILoadControl

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, ProductManagerDelegate, UIScrollViewDelegate {

    @IBOutlet weak var myCollectionView: UICollectionView!

    let productManager = ProductManager()
    var imageArray = [UIImage]()

       override func viewDidLoad() {
        super.viewDidLoad()

        productManager.delegate = self
        productManager.requestProducts()

        //gradient navigationBar
        var colors = [UIColor]()
        colors.append(UIColor(red: 3/255, green: 63/255, blue: 122/255, alpha: 1))
        colors.append(UIColor(red: 4/255, green: 107/255, blue: 149/255, alpha: 1))
        navigationController?.navigationBar.setGradientBackground(colors: colors)

        //        第一次登入後可取得使用者token，後續即可直接登入
        if (FBSDKAccessToken.current()) != nil {
            //            fetchProfile()
        }

        let flowLayout = UICollectionViewFlowLayout.init()

        flowLayout.minimumLineSpacing = 25

        flowLayout.minimumInteritemSpacing = 25

        flowLayout.sectionInset = UIEdgeInsets.init(top: 24, left: 20, bottom: 10, right: 20)

        myCollectionView.collectionViewLayout = flowLayout

        myCollectionView.delegate = self

        myCollectionView.dataSource = self

        self.navigationController?.navigationBar.layer.shadowColor = UIColor(red: 53/255.0, green: 184/255.0, blue: 208/255.0, alpha: 0.85).cgColor
        self.navigationController?.navigationBar.layer.shadowOpacity = 1
        self.navigationController?.navigationBar.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.navigationController?.navigationBar.layer.shadowRadius = 4

        myCollectionView.loadControl = UILoadControl(target: self, action: #selector(loadMore(sender:)))
        myCollectionView.loadControl?.heightLimit = 80.0
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        //swiftlint:disable force_cast
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection_cell", for: indexPath) as! MyCollectionViewCell
        //swiftlint:enable force_cast

        //Font
        cell.productName.font = UIFont.asiTextStyle5Font()
        cell.productPrice.font = UIFont.asiTextStyle6Font()

        //Image
        cell.productImage.image = imageArray[indexPath.item]

        //background shadow
        cell.backgroundShadow.layer.shadowColor = UIColor.black.cgColor
        cell.backgroundShadow.layer.shadowOpacity = 0.26
        cell.backgroundShadow.layer.shadowOffset = CGSize(width: 0, height: 1)
        cell.backgroundShadow.layer.shadowRadius = 1

        //bottom style
        cell.bottom.clipsToBounds = true
        cell.bottom.layer.masksToBounds = true
        cell.bottom.layer.cornerRadius = 1
        cell.bottom.layer.borderWidth = 0.2
        cell.bottom.layer.borderColor = UIColor(red: 165/255.0, green: 170/255.0, blue: 178/255.0, alpha: 1.0).cgColor

        //like style
        cell.like.tintColor = UIColor(red: 165/255.0, green: 170/255.0, blue: 178/255.0, alpha: 1.0)
        cell.like.clipsToBounds = true
        cell.like.layer.masksToBounds = true
        cell.like.layer.cornerRadius = 4
        cell.like.layer.borderWidth = 0.2
        cell.like.layer.borderColor = UIColor(red: 165/255.0, green: 170/255.0, blue: 178/255.0, alpha: 1.0).cgColor

        cell.productName.text = products[indexPath.item].name
        cell.productPrice.text = "$ \(products[indexPath.item].price)"

        return cell
    }
            // UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //返回每个item的size
        return CGSize.init(width: 154, height: 160)
    }

    func manager(_ manager: ProductManager, didGet products: [Product]) {
        if imageArray.count != products.count {
        for i in imageArray.count...products.count-1 {
            let url = URL(string: "http://52.198.40.72/patissier/products/\(products[i].id)/preview.jpg")
            if let data = try? Data(contentsOf: url!) {
                self.imageArray.append(UIImage(data: (data))!)
                }
            }
        }
        DispatchQueue.main.async {
            self.myCollectionView.reloadData()
        }
    }

    func manager(_ manager: ProductManager, didFailWith error: Error) {
        print(error)
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        DispatchQueue.main.async {
        scrollView.loadControl?.update()
        }
    }

    func loadMore(sender: AnyObject?) {

        DispatchQueue.main.asyncAfter(deadline: (.now() + 2.0)) {
            self.productManager.requestProducts()
            self.myCollectionView.loadControl?.endLoading()
            self.myCollectionView.reloadData()

        }
    }
}
