//
//  OutletController.swift
//  Patissier
//
//  Created by Francis Tseng on 2017/6/22.
//  Copyright © 2017年 Francis Tseng. All rights reserved.
//

import UIKit

class OutletController: UIViewController {
}
